//! Tests for persistence layer

mod storage_tests;
mod crud_tests;
mod transaction_tests;
mod query_tests;