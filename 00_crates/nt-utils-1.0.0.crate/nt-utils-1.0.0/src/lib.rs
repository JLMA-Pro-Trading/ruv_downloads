// Placeholder for nt-utils
