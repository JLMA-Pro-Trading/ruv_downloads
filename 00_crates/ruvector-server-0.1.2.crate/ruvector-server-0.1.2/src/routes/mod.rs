//! API routes

pub mod collections;
pub mod health;
pub mod points;
