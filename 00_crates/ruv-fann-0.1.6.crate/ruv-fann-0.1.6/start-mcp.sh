#!/bin/bash
# Simple wrapper script to start the ruv-swarm MCP server
exec /home/bron/projects/rswarm/ruv-swarm/target/debug/ruv-swarm-mcp
