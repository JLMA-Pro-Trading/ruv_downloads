// Placeholder for nt-portfolio
