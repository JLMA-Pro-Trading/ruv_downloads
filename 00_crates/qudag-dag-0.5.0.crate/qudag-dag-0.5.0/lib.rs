//! QuDAG dag module
#![deny(unsafe_code)]
#![warn(missing_docs)]

/// Module version
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
