pub mod syntax_highlighter;

pub use syntax_highlighter::SyntaxHighlighter;