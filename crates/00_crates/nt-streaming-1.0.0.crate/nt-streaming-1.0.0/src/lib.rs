// Placeholder for nt-streaming
