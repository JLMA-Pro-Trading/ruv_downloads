//! Exchange protocol stub - to be implemented by Core Implementation Agent

pub struct ExchangeProtocol;