//! Exchange ledger stub - to be implemented by Core Implementation Agent

pub struct Ledger;
