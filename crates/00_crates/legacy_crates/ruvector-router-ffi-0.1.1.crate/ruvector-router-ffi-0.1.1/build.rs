fn main() {
    napi_build::setup();
}
