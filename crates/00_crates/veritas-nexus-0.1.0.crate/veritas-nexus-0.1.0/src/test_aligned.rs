//! Test aligned_vec import

#[cfg(test)]
mod tests {
    #[test]
    fn test_aligned_vec_import() {
        // Try different ways to import aligned_vec
        use aligned_vec::*;
        // If this compiles, we know the import works
    }
}