//! WASM types for neural integration

use super::BridgeConfig;

/// Configuration for WASM bridge
pub type WasmBridgeConfig = BridgeConfig;